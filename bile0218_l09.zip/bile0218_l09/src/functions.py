"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-13"
-------------------------------------------------------
"""
def hash_table(slots, values):
    """
    -------------------------------------------------------
    Print a hash table of a set of values. The format is:
    Hash Slot Key
    ---- -- --------------------------
     695 2  Lasagna, 7
    1355 4  Butter Chicken, 2
    Do not create an actual Hash_Set.
    Use: hash_table(slots, values)
    -------------------------------------------------------
    Parameters:
       slots - the number of slots available (int > 0)
       values - the values to hash (list of ?)
    Returns:
       None
    -------------------------------------------------------
    """
    print("Hash     Slot Key")
    print("-------- ---- --------------------")
    
    for i in values:
        hash_item = hash(i)
        slot = hash_item % slots 
        print("{:8} {:3} {}".format(hash_item,slot,i))
        
    print("----------------------------------")
    
    return 
        