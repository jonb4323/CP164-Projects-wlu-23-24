"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-13"
-------------------------------------------------------
"""
from Hash_Set_array import Hash_Set
from functions import hash_table
from Food import Food

set1 = Hash_Set(2)

set1.insert(Food("HotDog",1,False,110))
set1.insert(Food("Carrot",1,True,50))

set1.remove(Food("HotDog",1,False,110))



