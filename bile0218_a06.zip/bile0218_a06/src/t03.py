"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-17"
-------------------------------------------------------
"""
from Deque_linked import Deque

list1 = Deque()

print("Inserting values to front dq1...")
list1.insert_front(4)
list1.insert_front(3)
list1.insert_front(2)
list1.insert_front(1)

print("Done")
print()
list2 = Deque()
print("Inserting values to rear dq2...")
list2.insert_rear(1)
list2.insert_rear(2)
list2.insert_rear(3)
list2.insert_rear(4)
print("Done")
print()
print("dq1:",list(list1))
print("dq2:",list(list2))

print()
print("Is dq1 empty?:",list1.is_empty())
print()
print("Length of dq1:",len(list1))
print()

print("Removing front and rear of dq1...")
list1.remove_front()
list1.remove_rear()
print("Done")
print()
print("dq1:",list(list1))
print("dq2:",list(list2))
print()
print("Peeking front of dq1:",list1.peek_front())
print("Peeking rear of dq1:",list1.peek_rear())
print()
print("Swapping front with rear (dq2)...")
print()
print("dq2:",list(list2))

print()
print("dq2 (front):",list2._front._value)
print("dq2 (rear):",list2._rear._value)
print()
list2._swap(list2._front,list2._rear)

print("Done")
print()
print("dq2:",list(list2))
