"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
from Queue_linked import Queue

queue = Queue()

queue.insert(1)
queue.insert(2)
queue.insert(3)
queue.insert(4)

print("Queue:",list(queue))
print("Is empty?:",queue.is_empty())
print("length:",len(queue))
print("Removing:",queue.remove())
print("Queue:",list(queue))
print("Peeking:",queue.peek())

source = Queue()

source.insert(9)
source.insert(8)
source.insert(7)

print()
print("Queue1:",list(queue))
print("Queue2:",list(source))
print("Moving f -> r")
queue._move_front_to_rear(source)
print("Queue1:",list(queue))
print("Queue2:",list(source))

print()
print("Source:",list(source))
print("Q1:",list(queue))
print("Appending q1 to source")
source._append_queue(queue)
print(list(source))

q1 = Queue()
q2 = Queue()

q1.insert(1)
q1.insert(2)
q1.insert(3)
q1.insert(4)
q2.insert(6)
q2.insert(7)
q2.insert(8)
q2.insert(9)

source1 = Queue()

print()
print("Q1:",list(q1))
print("Q2:",list(q2))
print("Combining q1 & q2")
source1.combine(q1,q2)
print("Combined:",list(source1))

print()
print("Split-Alt")
print("Queue thats getting split:",list(source1))
t1,t2 = source1.split_alt()
print()

q3 = Queue()
q4 = Queue()

q3.insert(1)
q3.insert(2)
q4.insert(1)
q4.insert(2)

print("Q3:",list(q3))
print("Q4:",list(q4))
print("Are q3 == q4",q3 == q4)
