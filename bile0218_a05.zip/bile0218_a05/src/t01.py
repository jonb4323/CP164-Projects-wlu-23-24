"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-02"
-------------------------------------------------------
"""
from List_array import List
from Food import Food

list1 = List()
list2 = List()

list1.append(Food("HotDog",1,False,110))
list2.append(Food("HotDog",1,False,110))

print("Is List1 == List2 (True):",list1 == list2)
print()

print("Getting item [0] (HotDog):",list1[0])
print()

print("Appending Carrot...")
list1.append(Food("Carrot",7,True,78))
print("Done")
print()

list1.append(Food("Carrot",7,True,78))
list1.append(Food("Carrot",7,True,78))
list1.append(Food("Carrot",7,True,78))
print("Testing Clean adding 3 more carrots")
print()
list1.clean()
print("All items in list after clean (Removed 3 extra Carrots)")
print(list1[0])
print(list1[1])

print()
print("Combining list1 and list2 (source list3)...")

list3 = List()

list3.combine(list1,list2)

print("Done")
print()
print("Verifying Combine Works (two hotdogs)")
print(list3[0])
print(list3[1])

print()
print("Testing Intersection...")

list4 = List()

list1.append(Food("HotDog",1,False,110))
list2.append(Food("HotDog",1,False,110))

list4.intersection(list1, list2)

print("Done")
print()
print("Verifying Intersection Worked (hotdog)")
print(list4[0])
print()

print("Prepend Carrot to List4...")

list4.prepend(Food("Carrot",7,True,78))

print("Done")
print()
print("Testing front of list4 (Carrot)")
print(list4[0])

print("Removing front (Carrot)...")

list4.remove_front()

print("Done")

print()
print("Checking list4[0] = (hotdog)")
print(list4[0])

print()
print("Appending 3 more carrots")
list4.append(Food("Carrot",7,True,78))
list4.append(Food("Carrot",7,True,78))
list4.append(Food("Carrot",7,True,78))
print()

print("Removing all Carrots from list4...")

list4.remove_many(Food("Carrot",7,True,78))

print("Done")
print()

print("List4[0] is hotdog")
print(list4[0])

print()

print("Splitting list4 and appending 1 carrot...")

list4.append(Food("Carrot",7,True,78))
t1, t2 = list4.split()

print("Done")
print()
print("Hotdog ->",t1[0])
print("Carrot ->",t2[0])

print()

print("Testing split_alt and appending carrot and hotdog to list4...")

list4.append(Food("Carrot",7,True,78))
list4.append(Food("HotDog",1,False,110))

t1, t2 = list4.split_alt()

print("Done")
print()

print("HotDog ->",t1[0])
print("Carrot ->",t2[0])

print()
print("Testing Union and appending carrot and hotdog to list4 and list5...")

list4.append(Food("Carrot",7,True,78))
list4.append(Food("Carrot",7,True,78))

list5 = List()

list4.append(Food("HotDog",1,False,110))

list9 = List()

list9.union(list4,list5)

print("Done")
print()

print("Verifying (1 carrot and 1 hotdog)")
print(list9[0])
print(list9[1])

