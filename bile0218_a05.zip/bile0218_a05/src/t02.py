"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-03"
-------------------------------------------------------
"""
from Sorted_List_array import Sorted_List
from Food import Food

list1 = Sorted_List()
list2 = Sorted_List()

print("Inserting hotdog -> list1 & carrot -> list2")
print()

list1.insert(Food("HotDog",1,False,110))
list2.insert(Food("Carrot",7,True,78))

print("Testing Contains in list1 for HotDog...")

print("Should be True:",list1.__contains__(Food("HotDog",1,False,110)))

print("Done")

print()
print("Testing if list1 == list2 (False):",list1 == list2)
print()

print("Appending 3 more carrots an d 1 hotdog")

list2.insert(Food("Carrot",7,True,78))
list2.insert(Food("Carrot",7,True,78))
list2.insert(Food("Carrot",7,True,78))
list2.insert(Food("HotDog",1,False,110))

print()
print("Cleaning list2 of carrots...")

list2.clean()

print()
print("Done, should only be 1 hotdog and 1 carrot")

print(list2[0])
print(list2[1])

print()

print("Counting how many carrots in list2 (1):",list2.count(Food("Carrot",7,True,78)))

print()
print("Finding carrot?:",list2.find(Food("Carrot",7,True,78)))
print()

print("Getting index of hotdog (1):",list2.index(Food("HotDog",1,False,110)))
print()

print("Testing Intersection...")

list4 = Sorted_List()

list4.intersection(list1,list2)

print("Should be hotdog:",list4[0])

print("Done")

print()

print("Appending 1 carrot to list4")
list4.insert(Food("Carrot",7,True,78))

print()
print("Testing Max (HotDog):",list4.max())
print("Testing Min (Carrot):",list4.min())
print()

print("Peeking list4 (Carrot):",list4.peek())
print()

print("Removing Carrot...")

list4.remove(Food("Carrot",7,True,78))

print("Done")

print("Should be hotdog ->",list4[0])

print()

print("Removing front (hotdog):",list4.remove_front())

print("Done")

print()

print("Appending 3 Carrots to list4")
print()

list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("Carrot",7,True,78))

print("Removing all carrots from list4...")

list4.remove_many(Food("Carrot",7,True,78))

print("Done")

print()

list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("HotDog",1,False,110))

print("Splitting list4 into t1 and t2...")

t1,t2 = list4.split()

print("Done")

print()
print("Inserting carrots and hotdogs into list4...")

list4.insert(Food("HotDog",1,False,110))
list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("HotDog",1,False,110))
list4.insert(Food("Carrot",7,True,78))

print("Testing Split-Alt...")

t1,t2 = list4.split_alt()

print("Done")

print()
print("Should be 1 hotdog and 1 carrot in t1")
print(t1[0])
print(t1[1])
print()

print("Should be 1 hotdog and 1 carrot in t2")
print(t2[0])
print(t2[1])

print()
print("Inserting carrots and hotdogs into list4...")

list4.insert(Food("HotDog",1,False,110))
list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("Carrot",7,True,78))
list4.insert(Food("Peanuts",7,False,670))

print()

print("Testing split_key on list19 (carrot)...")

list19 = Sorted_List()

list19.insert(Food("Apple",1,False,90))
list19.insert(Food("Broccoli",2,True,78))
list19.insert(Food("Broccoli",2,True,78))
list19.insert(Food("Carrot",3,True,56))
list19.insert(Food("Dino Nuggets",4,False,170))
list19.insert(Food("Elephant",9,True,780))

t1,t2 = list19.split_key(Food("Carrot",3,True,56))

print("Done")
print()
print("Split by key t1:")
for i in t1:
    print(i)

print()
print("Split by key t2:")
for i in t2:
    print(i)
    
print()

list10 = Sorted_List()

list10.insert(Food("Carrot",7,True,78))
list10.insert(Food("HotDog",1,False,110))

print("Testing Union...")

list8 = Sorted_List()

list8.union(list4,list10)

print("Done")

print()
print("Should be 1 of each (carrot, peanuts and hotdog)")
for i in list8:
    print(i)
