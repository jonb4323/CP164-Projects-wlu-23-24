"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-12"
-------------------------------------------------------
"""
from Food_utilities import read_foods

with open('test_foods.txt', 'r') as file_handle:
    foods_list = read_foods(file_handle)

for food in foods_list:
    print(food)