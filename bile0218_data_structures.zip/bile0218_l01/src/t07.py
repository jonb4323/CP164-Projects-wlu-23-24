"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-12"
-------------------------------------------------------
"""
from Food_utilities import Food, get_vegetarian

foods_list = [
    Food("Pizza", 2, False, 300),
    Food("Sushi", 6, True, 250),
    Food("Pasta", 2, False, 400),
    Food("Burger", 9, False, 500),
]

vegetarian_foods = get_vegetarian(foods_list)

for veggie_food in vegetarian_foods:
    print(veggie_food)