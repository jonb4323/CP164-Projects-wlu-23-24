"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-19"
-------------------------------------------------------
"""
from BST_linked import BST

bst = BST()

bst.insert(1)
bst.insert(234)
bst.insert(6)
bst.insert(4)
bst.insert(77)

print("BST:",list(bst))

zero,one,two = bst.node_counts()

print()
print("BST Zero child nodes:",zero)
print("BST One child nodes:",one)
print("BST Two child nodes:",two)

print()
print("Does bst contain[1]:",bst.__contains__(1))

print()

print("Parent of 77:",bst.parent(77))
print("(Recursive) Parent of 77:",bst.parent_r(77))