"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-19"
-------------------------------------------------------
"""
from functions import insert_words, comparison_total
from Hash_Set_sorted import Hash_Set

hs = Hash_Set(20)

with open('otoos610.txt','r') as fv:
    insert_words(fv, hs)
    
for item in hs:
    print(item)
    
total,max_word = comparison_total(hs)

print()
print("Total Comparisons:",total)
print("Word w/ most Comparisons:",max_word)