"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-01"
-------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue

source = Priority_Queue()

source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)
source.insert(5)

t1,t2 = source.split_key(3)

print("The key is '3'")
print("t1: ",list(t1))
print("t2: ",list(t2))