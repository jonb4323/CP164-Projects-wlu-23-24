"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-30"
-------------------------------------------------------
"""
from Queue_array import Queue

queue = Queue()

queue.insert(1)
queue.insert(2)
queue.insert(3)
queue.insert(4)
queue.insert(5)

print("Queue: {}".format(queue._values))

t1, t2 = queue.split_alt()

print("Split Q1:",list(t1))
print("Split Q2:",list(t2))
