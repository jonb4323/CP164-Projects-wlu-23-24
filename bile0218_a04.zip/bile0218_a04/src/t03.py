"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-30"
-------------------------------------------------------
"""
from functions import queue_split_alt
from Queue_circular import Queue

queue = Queue(7)

queue.insert(1)
queue.insert(2)
queue.insert(3)
queue.insert(4)
queue.insert(5)
queue.insert(6)
queue.insert(7)

print("Q1: {}".format(queue._values))

split_queue = queue_split_alt(queue)

for i, split_queue in enumerate(split_queue):
    print("Split Queue {}: {}".format(i + 1, split_queue._values))