"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-30"
-------------------------------------------------------
"""
from Queue_circular import Queue

q1 = Queue(5)
a1 = [8,12,8,5,7]

for i in a1:
    q1.insert(i)
    
print("Q1: {}".format(q1._values))
print("Is Q1 Empty?:",q1.is_empty())
print("Is Q1 Full?",q1.is_full())
print("Length of Q1:",len(q1))
print("Removing first value (Q1)",q1.remove())
print("Peeking at First index:",q1.peek())
print("Q1: {}".format(q1._values))
