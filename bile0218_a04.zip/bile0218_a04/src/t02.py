"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-30"
-------------------------------------------------------
"""
from Queue_array import Queue 

q1 = Queue()
q1.insert(1)
q1.insert(2)

q2 = Queue()
q2.insert(1)
q2.insert(2)

print("Q1: {}".format(q1._values))
print("Q2: {}".format(q2._values))

temp = False 

if q1 == q2:
    temp = True

print("Are these queues equal?:",temp)