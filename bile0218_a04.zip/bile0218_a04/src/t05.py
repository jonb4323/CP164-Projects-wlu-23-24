"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-01"
-------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue
from functions import pq_split_key

pq = Priority_Queue()

pq.insert(1)
pq.insert(2)
pq.insert(3)
pq.insert(4)
pq.insert(5)

t1,t2 = pq_split_key(pq,3)

print("The key is '3'")
print("T1:",list(t1))
print("T2:",list(t2))
