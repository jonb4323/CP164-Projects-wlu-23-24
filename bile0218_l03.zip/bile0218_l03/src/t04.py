"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import array_to_pq, Priority_Queue

pq = Priority_Queue()
source = [('apple', 3), ('banana', 1), ('orange', 2)]

print("Initial Priority Queue:", list(pq))
print("Initial Source:", source)

array_to_pq(pq, source)

print("Final Priority Queue:", list(pq))
print("Final Source:", source)