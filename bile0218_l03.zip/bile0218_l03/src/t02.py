"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import queue_to_array, Queue

queue = Queue()
source = [1, 2, 3, 4, 5]

print("Initial Queue:", list(queue))
print("Initial Source:", source)

target = [1,2,3,4,5]

result_array = queue_to_array(queue,target)

print("Result Array:", result_array)
print("Final Queue:", list(queue))
print("Final Source:", source)