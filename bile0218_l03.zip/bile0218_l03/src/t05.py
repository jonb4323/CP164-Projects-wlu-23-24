"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import pq_to_array, array_to_pq, Priority_Queue

pq = Priority_Queue()

source = [1,2,3,4,5]

array_to_pq(pq, source)

print("pq list:", list(pq))
print("pq source:", list(source))

pq_to_array(pq, source)
    
print("pq list:", list(pq))
print("pq source:", list(source))