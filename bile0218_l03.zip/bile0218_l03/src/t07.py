"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import priority_queue_test

from Food_utilities import read_foods

file = open("foods.txt", "r", encoding="utf-8")

food_read = read_foods(file)

priority_queue_test(food_read)