"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import queue_test, Queue

data_list = [1, 2, 3, 4, 5]
queue_test(data_list)