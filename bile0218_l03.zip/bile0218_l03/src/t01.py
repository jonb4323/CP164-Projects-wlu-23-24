"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-19"
-------------------------------------------------------
"""
from utilities import array_to_queue, Queue

queue = Queue()

source = [1, 2, 3, 4, 5]

print("Initial Queue:", list(queue))
print("Initial Source:", source)

array_to_queue(queue, source)

print("Final Queue:", list(queue))
print("Final Source:", source)