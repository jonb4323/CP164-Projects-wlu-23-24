"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-17"
-------------------------------------------------------
"""
from utilities import stack_to_array, Stack

stack = Stack()

for i in range(1, 6):
    stack.push(i)

print("Initial Stack:", list(stack))

target = []

stack_to_array(stack, target)

    
print("Final Stack:", list(stack))
print("Final Target:", target)