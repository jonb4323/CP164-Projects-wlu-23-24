"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-17"
-------------------------------------------------------
"""
from utilities import stack_test

from Food_utilities import read_foods

file = open("foods.txt", "r", encoding="utf-8")

food_read = read_foods(file)

stack_test(food_read)
