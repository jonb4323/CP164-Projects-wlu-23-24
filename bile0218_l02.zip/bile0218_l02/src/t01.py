"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-17"
-------------------------------------------------------
"""
from utilities import array_to_stack, Stack

stack = Stack()
 
source = [1, 2, 3, 4, 5]

    
print("Initial Stack:", list(stack))
print("Initial Source:", source)

array_to_stack(stack, source)

print("Final Stack:", list(stack))
print("Final Source:", source)