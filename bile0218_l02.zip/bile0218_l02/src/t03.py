"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-17"
-------------------------------------------------------
"""
from utilities import Stack

stack = Stack()

source = [1, 2, 3, 4, 5]

print("Before push, is_empty expects True:", stack.is_empty())

for i in source:
    print("Pushed:", i)
    stack.push(i)

print("After push, expects False:", stack.is_empty())

while not stack.is_empty():
    print("Peek:", stack.peek())
    popped_value = stack.pop()
    print("Popped:", popped_value)

 