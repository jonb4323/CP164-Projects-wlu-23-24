"""
-------------------------------------------------------
linked version of the Priority Queue ADT.
-------------------------------------------------------
Author:  David Brown
ID:      123456789
Email:   dbrown@wlu.ca
__updated__ = "2023-05-07"
-------------------------------------------------------
"""
from copy import deepcopy

class _PQ_Node:

    def __init__(self, value, _next):
        """
        -------------------------------------------------------
        Initializes a priority queue node that contains a copy of value
        and a link to the next node in the priority queue
        Use: node = _PQ_Node(value, _next)
        -------------------------------------------------------
        Parameters:
            value - value value for node (?)
            _next - another priority queue node (_PQ_Node)
        Returns:
            a new Priority_Queue object (_PQ_Node)
        -------------------------------------------------------
        """
        self._value = deepcopy(value)
        self._next = _next


class Priority_Queue:

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty priority queue.
        Use: pq = Priority_Queue()
        -------------------------------------------------------
        Returns:
            a new Priority_Queue object (Priority_Queue)
        -------------------------------------------------------
        """
        self._front = None
        self._rear = None
        self._count = 0

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the priority queue is empty.
        Use: b = pq.is_empty()
        -------------------------------------------------------
        Returns:
            True if priority queue is empty, False otherwise.
        -------------------------------------------------------
        """
        return self._count == 0

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the length of the priority queue.
        Use: n = len(pq)
        -------------------------------------------------------
        Returns:
            the number of values in the priority queue.
        -------------------------------------------------------
        """
        return self._count

    def insert(self, value):
        """
        -------------------------------------------------------
        A copy of value is inserted into the priority queue.
        Values are stored in priority order. 
        Use: pq.insert(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        node = _PQ_Node(deepcopy(value), None)
        
        if self._count == 0 or node._value < self._front._value:
            node._next = self._front
            self._front = node
            if self._count == 0:
                self._rear = node
        else:
            current = self._front
            while current._next is not None and node._value >= current._next._value:
                current = current._next
            node._next = current._next
            current._next = node
            
            if current == self._rear:
                self._rear = node
    
        self._count += 1

        return

    def remove(self):
        """
        -------------------------------------------------------
        Removes and returns the highest priority value from the priority queue.
        Use: value = pq.remove()
        -------------------------------------------------------
        Returns:
            value - the highest priority value in the priority queue -
                the value is removed from the priority queue. (?)
        -------------------------------------------------------
        """
        assert self._count > 0, "Cannot remove from an empty priority queue"

        value = deepcopy(self._front._value)
        
        self._front = self._front._next
        
        if self._front is None:
            self._rear = None 
        self._count -= 1
        
        return value

    def peek(self):
        """
        -------------------------------------------------------
        Peeks at the highest priority value of the priority queue.
        Use: v = pq.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the highest priority value in the priority queue -
                the value is not removed from the priority queue. (?)
        -------------------------------------------------------
        """
        assert self._count > 0, "Cannot peek at an empty priority queue"

        val = deepcopy(self._front._value)

        return val

    def split_alt(self):
        """
        -------------------------------------------------------
        Splits a priority queue into two with values going to alternating
        priority queues. The source priority queue is empty when the method
        ends. The order of the values in source is preserved.
        Use: target1, target2 = source.split_alt()
        -------------------------------------------------------
        Returns:
            target1 - a priority queue that contains alternating values
                from the current queue (Priority_Queue)
            target2 - priority queue that contains  alternating values
                from the current queue  (Priority_Queue)
        -------------------------------------------------------
        """
        t1 = Priority_Queue()
        t2 = Priority_Queue()
            
        insert_bool = True 
        
        if self._count == 1:
            t1._front = self._front 
            t1._rear = self._rear
            self._front = None
            self._rear = None
            t1._count += 1
        
        else:
            while self._front is not None:
                if insert_bool:
                    if t1._front is None:
                        t1._front = self._front
                        t1._rear = self._front
                    else:
                        t1._rear._next = self._front
                        t1._rear = t1._rear._next
                    t1._count += 1
                else:
                    if t2._front is None:
                        t2._front = self._front
                        t2._rear = self._front
                    else:
                        t2._rear._next = self._front
                        t2._rear = t2._rear._next
                    t2._count += 1
                    
                self._front = self._front._next
                insert_bool = not insert_bool
            
            if t1._rear is not None:
                t1._rear._next = None
            if t2._rear is not None:
                t2._rear._next = None
            
        self._front = None 
        self._rear = None 
        self._count = 0
        
        return t1,t2

    def split_key(self, key):
        """
        -------------------------------------------------------
        Splits a priority queue into two depending on an external
        priority key. The source priority queue is empty when the method
        ends. The order of the values in source is preserved.
        Use: target1, target2 = pq1.split_key(key)
        -------------------------------------------------------
        Parameters:
            key - a data object (?)
        Returns:
            target1 - a priority queue that contains all values
                with priority higher than key (Priority_Queue)
            target2 - priority queue that contains all values with
                priority lower than or equal to key (Priority_Queue)
        -------------------------------------------------------
        """
        t1 = Priority_Queue()
        t2 = Priority_Queue()
        
        while self._front is not None:
            curr_node = self._front
            self._front = self._front._next
            curr_node._next = None 

            if curr_node._value < key:
                if t1._front is None:
                    t1._front = curr_node
                    t1._rear = curr_node
                else:
                    t1._rear._next = curr_node
                    t1._rear = t1._rear._next
                t1._count += 1
            else:
                if t2._front is None:
                    t2._front = curr_node
                    t2._rear = curr_node
                else:
                    t2._rear._next = curr_node
                    t2._rear = t2._rear._next
                t2._count += 1
        
        if t1._rear is not None:
            t1._rear._next = None
        if t2._rear is not None:
            t2._rear._next = None

        self._rear = None
        self._count = 0
        
        return t1,t2

    def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines two source queues into the current target priority queue. 
        When finished, the contents of source1 and source2 are inserted 
        into target and source1 and source2 are empty. Order is preserved
        with source1 elements having priority over source2 elements with the
        same priority value.
        (iterative algorithm)
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - a linked priority queue (Priority_Queue)
            source2 - a linked priority queue (Priority_Queue)
        Returns:
            None
        -------------------------------------------------------
        """
        scr1_node = source1._front 
        scr2_node = source2._front
    
        while scr1_node is not None and scr2_node is not None:
            if scr1_node._value <= scr2_node._value:
                next_node = scr1_node
                scr1_node = scr1_node._next
            else:
                next_node = scr2_node
                scr2_node = scr2_node._next
            
            if self._front is None:
                self._front = next_node
                self._rear = next_node
            else:
                self._rear._next = next_node
                self._rear = next_node
            self._count += 1
    
        while scr1_node is not None:
            if self._front is None:
                self._front = scr1_node
                self._rear = scr1_node
            else:
                self._rear._next = scr1_node
                self._rear = scr1_node
            self._count += 1
            scr1_node = scr1_node._next
    
        while scr2_node is not None:
            if self._front is None:
                self._front = scr2_node
                self._rear = scr2_node
            else:
                self._rear._next = scr2_node
                self._rear = scr2_node
            self._count += 1
            scr2_node = scr2_node._next 
        
        source1._front = None
        source2._front = None
        source1._rear = None
        source2._rear = None
        source1._count = 0
        source2._count = 0

    def _append_queue(self, source):
        """
        -------------------------------------------------------
        Appends the entire source queue to the rear of the target queue.
        The source queue becomes empty.
        Use: target._append_queue(source)
        -------------------------------------------------------
        Parameters:
            source - an linked-based queue (Queue)
        Returns:
            None
        -------------------------------------------------------
        """
        assert source._front is not None, "Cannot append an empty priority queue"

        self._count += source._count
        
        if self._front is None:
            self._front = source._front
            self._rear = source._rear
        else:
            self._rear._next = source._front 
            self._rear = source._rear
            
        source._front = None
        source._rear = None
        source._count = 0
                    
        return

    def _move_front_to_rear(self, source):
        """
        -------------------------------------------------------
        Moves the front node from the source queue to the rear of the target queue.
        The target queue contains the old front node of the source queue.
        The source queue front is updated. Order is preserved.
        Use: target._move_front_to_rear(source)
        -------------------------------------------------------
        Parameters:
            source - a linked queue (Queue)
        Returns:
            None
        -------------------------------------------------------
        """
        assert source._front is not None, "Cannot move the front of an empty priority queue"

        fn = source._front
        source._front = source._front._next
        
        if self._front is None:
            self._rear = None
            self._front = fn
            source._count -= 1
        else:
            self._rear._next = fn
            source._count -= 1
            
        if source._count == 0:
            source._rear = None
            
        self._rear = fn
        self._rear._next = None
        self._count += 1
        
        return
    
    def __eq__(self, target):
        """
        ---------------------------------------------------------
        Determines whether two Queues are equal.
        Values in self and target are compared and if all values are equal
        and in the same order, returns True, otherwise returns False.
        Use: equals = source == target
        ---------------
        Parameters:
            target - a queue (Queue)
        Returns:
            equals - True if source contains the same values
                as target in the same order, otherwise False. (boolean)
        -------------------------------------------------------
        """
        equal = False
        
        if self._count == 0 and target._count == 0:
            equal = True
        
        if self._count == target._count and self._count > 0 and equal is False:
            src_node = self._front
            tgt_node = target._front
                        
            while src_node is not None:
                if src_node._value == tgt_node._value:
                    equal = True 
                else:
                    equal = False 
                    break
                
                src_node = src_node._next
                tgt_node = tgt_node._next
            
        return equal
    
    def __iter__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the queue
        from front to rear.
        Use: for value in pq:
        -------------------------------------------------------
        Returns:
            value - the next value in the priority queue (?)
        -------------------------------------------------------
        """
        current = self._front

        while current is not None:
            yield current._value
            current = current._next