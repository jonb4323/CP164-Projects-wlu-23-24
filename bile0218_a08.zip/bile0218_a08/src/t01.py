"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-05"
-------------------------------------------------------
"""
from BST_linked import BST

bst = BST()

bst.insert(1)
bst.insert(2)
bst.insert(3)
bst.insert(4)
bst.insert(5)

bst1 = BST()

bst1.insert(1)
bst1.insert(2)
bst1.insert(3)
bst1.insert(4)
bst1.insert(5)

print("BST-> ",list(bst))
print("BST1-> ",list(bst1))
print()
print("Is BST == BST1:",bst == bst1)
print()
print("Is BST balanced:",bst.is_balanced())
print()
print("Is BST valid:",bst.is_valid())
print()
print("Min in BST:",bst.min())
print()
print("Leaf count:",bst.leaf_count())
print()
print("OCC:",bst.one_child_count())
print()
print("TCC:",bst.two_child_count())
print()
print("IO:",bst.inorder())
print()
print("PreO:",bst.preorder())
print()
print("PosO:",bst.postorder())
print()
print("LO:",bst.levelorder())
print()
print("Removing Node w/ value '1':",bst.remove(1))