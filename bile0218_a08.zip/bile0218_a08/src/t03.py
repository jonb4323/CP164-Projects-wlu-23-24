"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-14"
-------------------------------------------------------
"""
from BST_linked import BST
from Letter import Letter
from functions import letter_table

bst = BST()

with open("miserables.txt", "r") as file_variable:
    data = file_variable.read()
    for letter in data:
        if letter.isalpha():
            bst.insert(Letter(letter.upper()))

for i in bst:
    print(i)
letter_table(bst)