"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-14"
-------------------------------------------------------
"""
from BST_linked import BST
from functions import do_comparisons, comparison_total
from Letter import Letter

bst1 = BST()
bst2 = BST()
bst3 = BST()

DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DATA2 = "MFTCJPWADHKNRUYBEIGLOQSVXZ"
DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"

for char in DATA1:
    bst1.insert(Letter(char))
for char in DATA2:
    bst2.insert(Letter(char))
for char in DATA3:
    bst3.insert(Letter(char))
    
with open("miserables.txt", "r") as file_variable:
    do_comparisons(file_variable, bst1)
    do_comparisons(file_variable, bst2)
    do_comparisons(file_variable, bst3)

total1 = comparison_total(bst1)
total2 = comparison_total(bst2)
total3 = comparison_total(bst3)

print("Comparing by order: {}".format(DATA1))
print("Total Comparisons: {:,}".format(total1))
print("------------------------------------------------------------")
print("Comparing by order: {}".format(DATA2))
print("Total Comparisons: {:,}".format(total2))
print("------------------------------------------------------------")
print("Comparing by order: {}".format(DATA3))
print("Total Comparisons: {:,}".format(total3))




