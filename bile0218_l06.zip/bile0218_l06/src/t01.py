"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-09"
-------------------------------------------------------
"""
from List_linked import List
from Food import Food

lst = List()

print("Appending 1,2,3 to list...")

lst.append(1)
lst.append(2)
lst.append(3)

print("Done")
print()

print("List:",list(lst))
print()
print("Inserting 4 to the end...")

lst.insert(3,4)

print("Done")
print()

print("List:",list(lst))

print()
print("Prepending 9 to list...")

lst.prepend(9)

print("Done")
print()

print("List:",list(lst))

print("Testing linear search for 4...")

prev_node,curr_node,index = lst._linear_search(4)

print("Done")
print()

print("Previous Node:",prev_node)
print("Current Node:",curr_node)
print("Index of Key:",index)

print()
print("Appending three 9's...")

lst.append(9)
lst.append(9)
lst.append(9)

print("Done")

print()
print("List:",list(lst))
print()

print("Testing count on 9 (4):",lst.count(9))
print()

print("Testing max on list (9):",lst.max())
print()

print("Testing min on list (1):",lst.min())
print()

print("Finding first occurrence of '3' (3):",lst.find(3))
print()

print("Finding (index) first occurrence of '3' (3):",lst.index(3))
print()
print("List:",list(lst))
print()

print("Does list contain '4'?:",lst.__contains__(4))
print()

print("Peeking list (9):",lst.peek())
print()
print("List:",list(lst))
print()

print("Removing first occurrence of '9':",lst.remove(9))
print()

print("List:",list(lst))
print()

print("What's at list[3]?:",lst[3])
print()

print("Setting index 0 to '155':",lst.__setitem__(0,155))
print()

print("List:",list(lst))
print()

print("Testing w/ Food")

list1 = List()

list1.append(Food("HotDog",1,False,110))

print()
print("Appended Hotdog:",list1[0])

list1.prepend(Food("Carrot",1,True,77))

print()
print("Prepending Carrot:",list1[0])
print()

list1.insert(0,Food("HotDog",1,False,110))

print("Inserting Hotdog [0]:",list1[0])
print()

print("Testing linear search 'Carrot'")

prev_node,curr_node,index = list1._linear_search(Food("Carrot",1,True,77))

print("prev_node:",prev_node)
print("curr_node:",curr_node)
print("Index:",index)

print()
print("Count hotdog in list1:",list1.count(Food("HotDog",1,False,110)))
print()

print("Max:",list1.max())
print("Min:",list1.min())

print()

print("Finding Carrot:",list1.find(Food("Carrot",1,True,77)))

print("Index of hotdog:",list1.index(Food("HotDog",1,False,110)))

print()
print("Does list1 contain carrot?:",list1.__contains__(Food("Carrot",1,True,77)))

print()
print("Peeking list1:",list1.peek())

print("Removing carrot:",list1.remove(Food("Carrot",1,True,77)))
print()

print("list1[0]:",list1[0])
list1[1] = Food("Carrot",1,True,77)
print("list1[1] = Carrot")
print("Done")
