"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-17"
-------------------------------------------------------
"""
from Food_utilities import food_search, Food

foods_list = [
    Food("Pizza", 7, False, 300),
    Food("Sushi", 2, True, 250),
    Food("Pasta", 6, False, 400),
    Food("Burger", 2, True, 500),
]

food_search(foods_list,2,500,True)