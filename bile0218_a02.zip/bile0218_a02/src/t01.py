"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-16"
-------------------------------------------------------
"""
from Food_utilities import by_origin, Food

foods_list = [
    Food("Pizza", 7, False, 300),
    Food("Sushi", 2, True, 250),
    Food("Pasta", 6, False, 400),
    Food("Burger", 2, False, 500),
]

by_origin(foods_list, 2)
