"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-26"
-------------------------------------------------------
"""
from List_linked import List 
from Sorts_List_linked import Sorts

a = List()

a.append(9234)
a.append(12)
a.append(5)
a.append(754)
a.append(1)
a.append(23)

print("Before Sort:",list(a))
print()

Sorts.radix_sort(a)

print("After Sort:",list(a))
print()
