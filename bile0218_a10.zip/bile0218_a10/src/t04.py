"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-26"
-------------------------------------------------------
"""
from Deque_linked import Deque 
from Sorts_Deque_linked import Sorts

a = Deque()

a.insert_front(5)
a.insert_front(2315125)
a.insert_front(123)
a.insert_front(34)
a.insert_front(1)

print("Before Sort:",list(a))
print()

Sorts.gnome_sort(a)

print("After Sort:",list(a))
print()
