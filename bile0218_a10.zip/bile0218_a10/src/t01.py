"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-26"
-------------------------------------------------------
"""
from Sorts_array import Sorts

a = [9,432,5,62,1,6,10,230230]

print("Before sort:",list(a))
print() 

Sorts.radix_sort(a)

print("After sort:",list(a))
print()

