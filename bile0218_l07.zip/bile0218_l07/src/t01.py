"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-25"
-------------------------------------------------------
"""
from List_linked import List

lst = List()

lst.insert(0,1)
lst.insert(1,2)
lst.insert(2,3)
lst.insert(3,4)

lst1 = List()

lst1.insert(0,3)
lst1.insert(1,4)
lst1.insert(2,5)
lst1.insert(3,6)

lst2 = List()

print("Testing Intersection...")
print()

print("List:",list(lst))
print("List1:",list(lst1))

lst2.intersection_r(lst,lst1)

print()

print("Testing Linear Search (key=4)...")

print()
print("List->",list(lst2))
print()

p_node, c_node, index = lst2._linear_search_r(4)

print("Current Node:",c_node._value)
print("Previous Node:",p_node._value)
print("Index at:",index)

print()
print("List1:",list(lst))
print("List2:",list(lst1))
print()
print("Are List1 == List2:",lst.is_identical_r(lst2))

print()
print("Testing Split_Alt w/ list1...")

t1,t2 = lst.split_alt_r()
print()
print("T1:",list(t1))
print("T2:",list(t2))

print()
print("Testing Union...")

list3 = List()

list3.insert(0,1)
list3.insert(1,2)
list3.insert(2,3)
list3.insert(3,4)

list4 = List()

list4.insert(0,3)
list4.insert(1,4)
list4.insert(2,5)
list4.insert(3,6)

print()
print("List3:",list(list3))
print("List4:",list(list4))

list5 = List()

print()
list5.union_r(list3, list4)

print("List5:",list(list5))

print()
print("Reversing List5...")

list5.reverse_r()
print()
print("List5:",list(list5))


