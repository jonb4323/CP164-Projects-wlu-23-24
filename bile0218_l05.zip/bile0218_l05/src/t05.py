"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
from functions import is_palindrome

print("Is Palindrome:", is_palindrome("A man, a plan, a canal, Panama"))
