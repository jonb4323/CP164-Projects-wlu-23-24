"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
from functions import recurse

print("Recurse:", recurse(3, 4))
