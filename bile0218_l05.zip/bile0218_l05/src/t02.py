"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
from functions import gcd

print("GCD (12,18):", gcd(12, 18))