"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
from functions import bag_to_set

bag = [1, 2, 2, 3, 4, 4, 5]
print("Bag to Set:", bag_to_set(bag))