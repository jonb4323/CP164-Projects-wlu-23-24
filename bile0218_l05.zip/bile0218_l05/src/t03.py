"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
from functions import vowel_count

print("Vowel Count:", vowel_count("Hello World"))