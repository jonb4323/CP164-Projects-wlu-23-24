"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-22"
-------------------------------------------------------
"""
from utilities import Stack

stack = Stack()

    
stack.push(1)
stack.push(2)
stack.push(3)

print("Original stack:", stack._values)

stack.reverse()

print("Reversed stack:", stack._values)
