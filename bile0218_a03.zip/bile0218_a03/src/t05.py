"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-22"
-------------------------------------------------------
"""
from functions import is_palindrome_stack

a1 = 'racecar'
  
print('String 1:', a1)

a2 = 'hello'

print('String 2:', a2)

target = is_palindrome_stack(a1)
unkown = is_palindrome_stack(a2)

print("First Stack is_Pal: ",target)
print("Second Stack is_Pal: ",unkown)