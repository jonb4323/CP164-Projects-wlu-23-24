"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-22"
-------------------------------------------------------
"""
from functions import postfix

case1 = '12 5 -'
case2 = '4 5 + 12 * 2 3 * -'

print('First Case:',case1)
print(postfix(case1))

print('Second Case:',case2)
print(postfix(case2))