"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import Stack

def stack_combine(source1, source2):
    """
    -------------------------------------------------------
    Combines two source stacks into a target stack.
    When finished, the contents of source1 and source2 are interlaced
    into target and source1 and source2 are empty.
    Use: target = stack_combine(source1, source2)
    -------------------------------------------------------
    Parameters:
        source1 - a stack (Stack)
        source2 - another stack (Stack)
    Returns:
        target - the contents of the source1 and source2
            are interlaced into target (Stack)
    -------------------------------------------------------
    """
    target = Stack()

    while not source1.is_empty() and not source2.is_empty():
        target.push(source1.pop())
        target.push(source2.pop())
        
    while not source1.is_empty():
        target.push(source1.pop())

    while not source2.is_empty():
        target.push(source2.pop())
    
    return target  

def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    temp_list = []

    while not source.is_empty():
        temp_list.append(source.pop())

    for item in temp_list:
        source.push(item)
    
    return 

def is_palindrome_stack(string):
    """
    -------------------------------------------------------
    Determines if string is a palindrome. Ignores case, digits, spaces, and
    punctuation in string.
    Use: palindrome = is_palindrome_stack(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        palindrome - True if string is a palindrome, False otherwise (bool)
    -------------------------------------------------------
    """
    stack = Stack()
    
    for i in range(len(string)):
        stack.push(string[i])
    
    returns = True
    
    for i in string:
        if i != stack.pop():
            returns = False
            
    return returns

OPERATORS = "+-*/"

def postfix(string):
    """
    -------------------------------------------------------
    Evaluates a postfix expression.
    Use: answer = postfix(string)
    -------------------------------------------------------
    Parameters:
        string - the postfix string to evaluate (str)
    Returns:
        answer - the result of evaluating string (float)
    -------------------------------------------------------
    """
    stack = Stack()

    new_string = string.split()

    for i in new_string:
        if i not in OPERATORS:
            stack.push(i)
        else:
            fst = float(stack.pop())
            snd = float(stack.pop())

            if i == '+':
                temp = snd + fst
                stack.push(temp)
            if i == '-':
                temp = snd - fst
                stack.push(temp)
            if i == '*':
                temp = snd * fst
                stack.push(temp)
            if i == '/':
                temp = snd / fst
                stack.push(temp)

    ans = stack.pop()
    
    return ans
               
def stack_maze(maze):
    """
    -------------------------------------------------------
    Solves a maze using Depth-First search.
    Use: path = stack_maze(maze)
    -------------------------------------------------------
    Parameters:
        maze - dictionary of points in a maze, where each point
            represents a corridor end or a branch. Dictionary
            keys are the name of the point followed by a list of
            branches, if any. First point is named 'Start', exit
            is named 'X' (dict)
    Returns:
        path - list of points visited before the exit is reached,
            None if there is no exit (list of str)
    -------------------------------------------------------
    """
    current = "Start"
    valids = maze[current]
    path = []
    
    if "X" in valids:
        path.append("X")
    stack = Stack()
    
    while "X" not in valids:
        for i in valids:
            stack.push(i)
        front = stack.pop()
        if maze[front]!=[]:
            path.append(front)          
        valids = maze[front]
        if "X" in valids:
            path.append("X")
            
    returns = path
    
    if len(path) == 0:
        returns = None
    
    return returns