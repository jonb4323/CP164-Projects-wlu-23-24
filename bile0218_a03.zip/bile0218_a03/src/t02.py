"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from utilities import Stack

s1 = Stack()
a1 = [8,12,8,5]

for i in a1:
    s1.push(i)

s2 = Stack()
a2 = [14,9,7,1,6,3]

s3 = Stack()

for i in a2:
    s2.push(i)

s3.combine(s1,s2)

print(list(s3))