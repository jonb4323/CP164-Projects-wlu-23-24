"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-22"
-------------------------------------------------------
"""
from functions import stack_reverse, Stack

stack = Stack()

for i in range(1, 6):
    stack.push(i * 7)

print("Stack b4 -> " ,list(stack))

stack_reverse(stack)

print("Stack After -> " ,list(stack))