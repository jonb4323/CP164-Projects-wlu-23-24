"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
from functions import stack_combine
from utilities import Stack

source1 = Stack()
a1 = [8,12,8,5]

for i in a1:
    source1.push(i)

source2 = Stack()
a2 = [14,9,7,1,6,3]

for i in a2:
    source2.push(i)


print("Source1:", list(source1))
print("Source2:", list(source2))

target = stack_combine(source1, source2)

print("Combined Stack:", list(target))
print("Is Source1 empty:", source1.is_empty())
print("Is Source2 empty:", source2.is_empty())