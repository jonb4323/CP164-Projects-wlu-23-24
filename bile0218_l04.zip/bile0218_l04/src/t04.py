"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-25"
-------------------------------------------------------
"""
from List_array import List

llist = List()

llist.append(1)
llist.append(2)
llist.append(3)
llist.append(4)

print("List->",list(llist))
print()

print("Testing __getitem__")

index = 1 
result = llist[index]

print("The val at '1':",result)
print()

index_to_set = 1
new_value = 10
llist[index_to_set] = new_value

print("Testing __setitem__")
print(f"Setting value {new_value} at index {index_to_set}")
print()
print("List->",list(llist))
