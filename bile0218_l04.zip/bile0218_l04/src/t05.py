"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-25"
-------------------------------------------------------
"""
from Food import Food


key = Food('Spring Rolls', 1, None, None)
print(key)