"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-25"
-------------------------------------------------------
"""
from List_array import List

llist = List()

print("Inserting values")
print()
print("B4->",list(llist))

llist.insert(0,1)
llist.insert(0,2)
llist.insert(0,3)
llist.insert(0,4)

print("Completed")
print("After->",list(llist))
print()
print("Appending values")
print()
print("B4->",list(llist))

llist.append(10)
llist.append(11)

print("Completed")
print("After->",list(llist))
print()
print("Remvoing values")
print()
print("B4->",list(llist))

llist.remove(1)
llist.remove(2)

print("Completed")
print("After->",list(llist))