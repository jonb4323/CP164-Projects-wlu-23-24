"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-25"
-------------------------------------------------------
"""
from List_array import List 

llist = List()

llist.append(1)
llist.append(2)
llist.append(3)
llist.append(4)

print('List->',list(llist))
print()
print("Testing index method")
print("""Asking for index of '3':""",llist.index(3))
print()
print("Testing index method")
print("Finding and copying first value '4':",llist.find(4))
print()
print("Testing __contains__")

key1 = 3
result1 = key1 in llist
print(f"Contains {key1}? Index: {result1}")

print()

llist.append(2)
llist.append(4)
llist.append(4)

print("List->",list(llist))
print()
print("Testing count")
print("Count num of '4':",llist.count(4))

print()
print("Testing Max and Min")
print("Min->",llist.min())
print("Max->",llist.max())
