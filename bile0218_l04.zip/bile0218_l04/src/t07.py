"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-28"
-------------------------------------------------------
"""
from utilities import list_to_array, List

llist = List()

source = []

llist.append(1)
llist.append(2)
llist.append(3)
llist.append(4)
llist.append(5)

print("Initial List:", list(llist))
print("Source List:", source)

list_to_array(llist,source)

print("\nFinal List:", list(llist))
print("Emptied Source List:", source)
