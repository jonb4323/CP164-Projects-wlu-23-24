"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-25"
-------------------------------------------------------
"""
from utilities import array_to_list, List

llist = List()

source = [1, 2, 3, 4, 5]

print("Initial List:", list(llist))
print("Source List:", source)

array_to_list(llist, source)

print("\nFinal List:", list(llist))
print("Emptied Source List:", source)
