"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-25"
-------------------------------------------------------
"""
from List_array import List

llist = List()

llist.insert(0,1)
llist.insert(0,2)
llist.insert(0,3)
llist.insert(0,4)


print("List->",list(llist))
key1 = 3
result1 = llist._linear_search(key1)
print(f"Search for {key1}: Index = {result1}")


key2 = 12
result2 = llist._linear_search(key2)
print(f"Search for {key2}: Index = {result2}")
