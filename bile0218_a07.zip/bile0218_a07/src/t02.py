"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-08"
-------------------------------------------------------
"""
from Sorted_List_linked import Sorted_List
from Food import Food

list1 = Sorted_List()

list1.insert(Food('HotDog',1,False,140))
list1.insert(Food('Carrot',5,True,15))

print("List1 -> ",list(list1))
print()
print("Does list1 contain hotdog:",list1.__contains__(Food('HotDog',1,False,140)))
print()

list2 = Sorted_List() 

list2.insert(Food('HotDog',1,False,140))
list2.insert(Food('Carrot',5,True,15))

print("List2 -> ",list(list2))
print()
print("List1 == List2:",list1 == list2)
print()
print("Clean list2, adding hotdog")
list2.insert(Food('HotDog',1,False,140))
list2.clean()
print()
print("List2 -> ",list(list2))
print()
print("Counting hotdogs in list2:",list2.count(Food('HotDog',1,False,140)))

print()
print("Finding Hotdog list2:",list2.find(Food('HotDog',1,False,140)))
print()

print("Index of hotdog:",list1.index(Food('HotDog',1,False,140)))
print()

print("Intersection list3 w/ list1,list2")

list3 = Sorted_List()

list3.intersection(list1, list2)

print()
print("List1 Max:",list1.max(),"Min:",list2.min())

print()

print("Peeking list1:",list1.peek())

print()
print("Removing HotDog:",list1.remove(Food('HotDog',1,False,140)))

print("Removing front of list1:",list1.remove_front())
print()
print("Union list2")
list3.union(list1,list2)