"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-03-07"
-------------------------------------------------------
"""
from List_linked import List 
from Food import Food 

list1 = List()

list1.append(Food('HotDog', 1, False, 170))
list1.append(Food('Carrot', 1, True, 15))

list2 = List()

list2.append(Food('HotDog', 1, False, 170))
list2.append(Food('Carrot', 1, True, 15))

print("List1 ->",list(list1))
print("List2 ->",list(list2))
print()
print("List1 == List2:",list1 == list2)
print()

print("List1[0]:",list1[0])
print()

print("Appending hotdog -> list1")

list1.append(Food('HotDog', 1, False, 170))
print()
print("Cleaning list1")
list1.clean()
print()

print("Combining list1 and list2")

list3 = List()

list3.combine(list1, list2)
print()
print("List3 -> ",list(list3))

print()
print("Intersection List3")
list3.intersection(list1,list2)
print()

print("Prepending HotDog -> list1")

list1.prepend(Food('HotDog', 1, False, 170))

print()

print("Removing Front list1")
list1.remove_front()

print()
print("Removing all hotdogs")

list1.remove_many(Food('HotDog', 1, False, 170))

print()
print("Spliting list4")


list4 = List()

list4.append(Food('HotDog', 1, False, 170))
list4.append(Food('Carrot', 1, True, 15))

t1,t2 = list4.split()

print("t1",list(t1))
print("t2",list(t2))

print()

print("Split alt list4")

list4.append(Food('HotDog', 1, False, 170))
list4.append(Food('Carrot', 1, True, 15))

t1,t2 = list4.split_alt()

print()
print("t1",list(t1))
print("t2",list(t2))

print()
print("Union list4")

list4.append(Food('HotDog', 1, False, 170))
list4.append(Food('Carrot', 1, True, 15))
list1.append(Food('HotDog', 1, False, 170))
list2.append(Food('Carrot', 1, True, 15))

list4.union(list1, list2)
print()
print(list(list4))
