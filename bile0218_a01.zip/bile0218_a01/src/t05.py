"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-10"
-------------------------------------------------------
"""
from functions import is_leap_year
print(is_leap_year(1996))