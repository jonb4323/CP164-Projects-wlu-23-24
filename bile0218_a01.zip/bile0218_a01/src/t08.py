"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-10"
-------------------------------------------------------
"""
from functions import matrix_stats
print(matrix_stats([[5, 2, 8, 3],
 [1, 7, 6, 0],
 [4, 9, 2, 5]]))