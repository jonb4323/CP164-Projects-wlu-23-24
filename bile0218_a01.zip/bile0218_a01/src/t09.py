"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-10"
-------------------------------------------------------
"""
from functions import matrixes_add
print(matrixes_add([[0, 1], [2, 3], [4, 5]], [[6, 7], [8, 9], [1, 0]]))

