"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-10"
-------------------------------------------------------
"""
from functions import is_valid
print(is_valid("v8***r"))
