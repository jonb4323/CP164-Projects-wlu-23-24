"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-10"
-------------------------------------------------------
"""

def clean_list(values):
    """
    -------------------------------------------------------
    Removes all duplicate values from a list: values contains
    only one copy of each of its integers. The order of values
    must be preserved.
    Use: clean_list(values)
    -------------------------------------------------------
    Parameters:
        values - a list of integers (list of int)
    Returns:
        None
    -------------------------------------------------------
    """
    values = list(dict.fromkeys(values))
    return None

def list_subtraction(minuend, subtrahend):
    """
    -------------------------------------------------------
    Alters the contents of minuend so that it does not contain
    any values in subtrahend.
    i.e. the values in the first list that appear in the second list
    are removed from the first list.
    Use: list_subtraction(minuend, subtrahend)
    -------------------------------------------------------
    Parameters:
        minuend - a list of values (list)
        subtrahend - a list of values to not include in difference (list)
    Returns:
        None
    ------------------------------------------------------
    """
    list = []
    for i in range(len(minuend)):
        result = True
        for j in range(len(subtrahend)):
            if (minuend[i] == subtrahend[j]):
                result = False
        if (result == True):
            list.append(minuend[i])
    minuend = list
    return None

def dsmvwl(string):
    """
    -------------------------------------------------------
    Disemvowels a string. out contains all the characters in s
    that are not vowels. ('y' is not considered a vowel.) Case is preserved.
    Use: out = dsmvwl(string)
    -------------------------------------------------------
    Parameters:
       string - a string (str)
    Returns:
       out - string with the vowels removed (str)
    -------------------------------------------------------
    """
    str = []
    for char in string:
        if char.lower() not in ['a','e','i','o','u']:
            str.append(char)
    return ''.join(str)
    
def file_analyze(fv):
    """
    -------------------------------------------------------
    Analyzes the characters in a file.
    The contents of the file must be unchanged:
    Do not strip() the lines.
    Use: upp, low, dig, whi, rem = file_analyze(fv)
    -------------------------------------------------------
    Parameters:
        fv - an already open file reference (file variable)
    Returns:
        upp - the number of uppercase letters in the file (int)
        low - the number of lowercase letters in the file (int)
        dig - the number of digits in the file (int)
        whi - the number of whitespace characters in the file (int)
        rem - the number of remaining characters in the file (int)
    -------------------------------------------------------
    """
    numUpper = 0
    numLower = 0
    numDig = 0
    numWhit = 0
    numRem = 0 
    
    i = 0
    for line in fv:
        for char in line:
            if char.isupper():
                numUpper += 1
            elif char.islower():
                numLower += 1
            elif char.isdigit():
                numDig += 1
            elif char.isspace():
                numWhit += 1
            else:
                numRem += 1
    return numUpper,numLower,numDig,numWhit,numRem

def is_leap_year(year):
    """
    -------------------------------------------------------
    Leap year determination.
    Use: leap_year = is_leap_year(year)
    -------------------------------------------------------
    Parameters:
        year - year to determine if it is a leap year (int > 0)
    Returns:
        leap_year - True if year is a leap year, False otherwise (boolean)
    -------------------------------------------------------
    """
    leapYear = False
    if year % 4 == 0:
        leapYear = True
        if year % 100 == 0:
            leapYear = False
            if year % 400 == 0:
                leapYear = True
    else:
        leapYear = False
    return(leapYear)

def is_valid(name):
    """
    -------------------------------------------------------
    Determines if name is a valid Python variable name.
    Variables names must start with a letter or an underscore.
    The rest of the variable name may consist of letters, numbers
    and underscores.
    Use: valid = is_valid(name)
    -------------------------------------------------------
    Parameters:
        name - a string to test as a Python variable name (str)
    Returns:
        valid - True if name is a valid Python variable name,
            False otherwise (boolean)
    -------------------------------------------------------
    """
    result = True
    if name[0].isalpha() != True or name[0] == '_':
        result = False 
    for char in name[1:]:
        if char.isalnum() == False or char == '_':
            result = False
            break
    return result
        
def max_diff(a):
    """
    -------------------------------------------------------
    Returns maximum absolute difference between adjacent values in a list.
    a must be unchanged.
    Use: md = max_diff(a)
    -------------------------------------------------------
    Parameters:
        a - a list of values (list of int)
    Returns:
        md - the largest absolute difference between adjacent
            values in a list (int)
    -------------------------------------------------------
    """
    listFinal = []
    for i in range(len(a)-1):
        biggest = a[i] - a[i+1]
        biggest = abs(biggest)
        listFinal.append(biggest)
    listFinal.sort()
    md = listFinal[-1]
    return md

def matrix_stats(a):
    """
    -------------------------------------------------------
    Determines the smallest, largest, total, and average of
    the values in the 2D list a. You may assume there is at
    least one value in a.
    a must be unchanged.
    Use: small, large, total, average = matrix_stats(a):
    -------------------------------------------------------
    Parameters:
        a - a 2D list of numbers (2D list of float)
    Returns:
        small - the smallest number in a (float)
        large - the largest number in a (float)
        total - the total of all numbers in a (float)
        average - the average of all numbers in a (float)
    -------------------------------------------------------
    """
    list = []
    
    small = 0
    large = 0
    total = 0
    avg = 0
    c = 0
    
    for i in range(len(a)):
        for j in range(len(a[i])):
            total += a[i][j]
            list.append(a[i][j])
            c += 1
    n = len(list)
    for i in range(len(list)):
        for j in range(0, len(list) - i - 1):   
            if list[j] > list[j + 1]:
                temp = list[j]
                list[j] = list[j+1]
                list[j+1] = temp
    small = list[0]
    large = list[-1]
    avg = total / c
    return small,large,total,avg

def matrixes_add(a, b):
    """
    -------------------------------------------------------
    Sums the contents of matrixes a and b. a and b must have
    the same number of rows and columns.
    a and b must be unchanged.
    Use: c = matrixes_add(a, b)
    -------------------------------------------------------
    Parameters:
        a - a 2D list (2D list of int/float)
        b - a 2D list (2D list of int/float)
    Returns:
        c - the matrix sum of a and b (2D list of int/float)
    -------------------------------------------------------
    """
    assert len(a) == len(b) and len(a[0]) == len(b[0]) 
    
    list = []
    
    for i in range(len(a)):
        c = []
        for j in range(len(a[i])):
            total = a[i][j] + b[i][j]       
            c.append(total)
        list.append(c)
    return list  