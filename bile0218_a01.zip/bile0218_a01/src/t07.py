"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-10"
-------------------------------------------------------
"""
from functions import max_diff
print(max_diff([40,20,10,5]))