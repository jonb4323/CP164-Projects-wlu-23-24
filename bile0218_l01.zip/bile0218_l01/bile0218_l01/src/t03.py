"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-12"
-------------------------------------------------------
"""
from Food_utilities import read_food
with open('foods.txt','r') as file_handle:
    for line in file_handle:
        food = read_food(line.strip())
        print(food)