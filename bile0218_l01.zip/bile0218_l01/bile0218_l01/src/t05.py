"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2024-01-12"
-------------------------------------------------------
"""
from Food_utilities import write_foods, Food

foods_list = [
    Food("Pizza", 7, False, 300),
    Food("Sushi", 0, True, 250),
    Food("Pasta", 6, False, 400),
    Food("Burger", 2, False, 500),
]

with open('test_foods.txt', 'w') as file_handle:
    write_foods(file_handle, foods_list)
